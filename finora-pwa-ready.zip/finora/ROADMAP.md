# FINORA continuation roadmap — request one prompt at a time

The starter includes the schema, server foundation, encrypted-field helper, MFA primitives, RBAC middleware, transaction creation, dashboard analytics/forecasting, cron bill reminders, and responsive public/auth/dashboard UI. The following prompts build the remaining production modules file-by-file.

1. **Authentication lifecycle:** "Implement FINORA production authentication endpoints file-by-file: registration, email verification, login, password reset, JWT access token, rotating HTTP-only refresh cookie, logout/revocation, workspace bootstrap, and MFA enrollment/challenge. Include tests and rate limits."
2. **Workspace permissions:** "Implement family workspace invitations, member management, Admin/Editor/Viewer policies, per-account visibility/edit permissions, and tests. Ensure every query scopes by workspace and account permission."
3. **Transaction manager:** "Extend transaction APIs with list/filter/search/pagination, edit/delete/reversal audit history, categories, subcategories, tags, attachment metadata, and tests. Add robust duplicate detection and deterministic internal transfer matching with explicit review for ambiguous pairs."
4. **Receipts:** "Implement private S3-compatible receipt upload/download using multer, MIME and size validation, malware-scanning interface, presigned URLs, PDF/image handling, and receipt-to-transaction linking."
5. **Bank syncing:** "Implement provider-neutral bank-sync adapter interfaces and webhook ingestion with signature verification, idempotency, encrypted credentials, cursor pagination, account mapping, pending-to-cleared updates, and transaction normalization. Include Plaid and India Account Aggregator adapter boundaries; do not fake provider credentials."
6. **Budgets and alerts:** "Implement monthly/weekly/custom budgets, rollover calculation, category aggregation, 80% and 100% threshold events, in-app notifications, email adapter, and scheduled reconciliation."
7. **Goals and bills:** "Implement savings goals, contribution/allocation ledger, target-date projections, recurring bill schedules, subscription detection, timezone-safe cron scheduling, and notification delivery."
8. **Debt and credit:** "Implement loan/debt records, amortization schedules, Snowball and Avalanche payoff plans, extra payment simulation, credit-card utilization against limits, and 30% alerts."
9. **Investments and net worth:** "Implement investment lots/transactions, stock/fund/crypto/fixed-deposit valuations, price-provider interfaces, realized/unrealized P&L, and asset/liability history snapshots."
10. **Analytics and forecasting:** "Implement multi-currency base normalization, live FX provider interface with rate timestamp/source, cash-flow forecasting with seasonality and confidence ranges, goal projections, category analytics, and net-worth history."
11. **Tax reports:** "Implement configurable tax categories, deductible expense reports, realized capital gains summaries, financial-year support for India, and CSV/XLSX/PDF exports with clear informational-only disclaimers."
12. **Import/export:** "Implement CSV/XLSX/PDF statement ingestion and export, mapping profiles, row-level validation, duplicate preview, dry-run and commit stages, and tests. PDF import must use text extraction/OCR adapters rather than pretending every PDF is machine-readable."
13. **Frontend completion:** "Build typed React pages and API hooks for all FINORA modules: accounts, transaction CRUD, receipts, budgets, goals, bills, debt, investments, family settings, notifications, reports and profile. Preserve the emerald design system and responsive accessibility."
14. **Production hardening:** "Add unit/integration/e2e tests, OpenAPI docs, structured logging, request IDs, audit events, CSP and cookie hardening, CSRF protection for cookie endpoints, observability, Docker Compose, CI pipeline, backups, migration strategy and deployment runbook."

## Release gates
- Never expose bank tokens or MFA secrets to the browser.
- Refresh tokens must be rotated, stored hashed, and revoked on reuse.
- Webhooks must verify provider signatures and be idempotent.
- Reconcile balances against provider statements; do not blindly mutate balances from duplicate webhook events.
- FX rates must include provider, timestamp and rate source.
- Reversals and transfer matches need auditable ledger entries.
- Validate all uploads and keep storage private.
- Obtain legal/compliance review before connecting real financial institutions.
