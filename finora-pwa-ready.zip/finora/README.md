# FINORA — Personal Finance Manager

A typed React + Express + PostgreSQL starter implementing the core architecture, schema, transaction engine, dashboard analytics, and the three primary UI surfaces.

## Prerequisites
- Node.js 20+
- PostgreSQL 15+
- npm

## Quick start
1. Copy `backend/.env.example` to `backend/.env` and set strong secrets.
2. `cd backend && npm install`
3. `npx prisma generate && npx prisma migrate dev --name init`
4. `npm run dev`
5. In another terminal: `cd frontend && npm install && npm run dev`

The frontend uses deterministic demo data and renders without a backend. Set `VITE_API_URL` to the backend URL to connect API calls.

## Security notes
- This is a secure-by-design development foundation, not a certified financial product.
- Keep encryption keys and JWT secrets in a secret manager in production.
- Use HTTPS, managed PostgreSQL backups, private object storage, malware scanning for uploads, and audited bank-provider integrations.
- Bank sync adapters are provider-neutral interfaces; real Plaid/Account Aggregator credentials and compliance approvals are required.
- MFA seed encryption, refresh-token rotation, RBAC, validation, rate limiting, and transaction atomicity are represented in the core.
- Application-level encryption is not end-to-end encryption: authorized server processes decrypt selected fields to perform operations.
- Do not use mock exchange rates or demo data for actual financial decisions.
