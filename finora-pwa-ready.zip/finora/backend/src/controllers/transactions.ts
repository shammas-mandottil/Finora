import type { Request, Response } from "express";
import { z } from "zod";
import { createTransaction } from "../services/transactions.js";

export const transactionSchema = z.object({
  accountId: z.string().min(1), type: z.enum(["INCOME","EXPENSE"]), amount: z.string().regex(/^\d+(\.\d{1,4})?$/),
  baseAmount: z.string().regex(/^\d+(\.\d{1,4})?$/), currency: z.string().length(3),
  description: z.string().trim().min(1).max(180), merchant: z.string().max(120).optional(),
  categoryId: z.string().optional(), transactionDate: z.string().datetime()
});
export async function postTransaction(req: Request, res: Response): Promise<void> {
  try {
    const result = await createTransaction({ ...req.body, workspaceId: req.auth!.workspaceId, createdById: req.auth!.userId });
    res.status(result.duplicate ? 200 : 201).json(result);
  } catch (error) { res.status(400).json({ error: error instanceof Error ? error.message : "Could not create transaction" }); }
}
