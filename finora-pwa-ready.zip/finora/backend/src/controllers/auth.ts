import type { Request, Response, NextFunction } from "express";
import bcrypt from "bcryptjs";
import { authenticator } from "otplib";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { encryptField, decryptField } from "../lib/crypto.js";
import { createOpaqueToken, createRefreshSecret, hashRefreshSecret, issueAccessToken, issueMfaChallenge, verifyMfaChallenge } from "../services/tokens.js";
import { sendSecurityEmail } from "../services/email.js";

const registerSchema = z.object({
  displayName: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(254).transform(v => v.toLowerCase()),
  password: z.string().min(10).max(128).regex(/[A-Za-z]/).regex(/[0-9]/)
});
const loginSchema = z.object({ email: z.string().email().transform(v => v.toLowerCase()), password: z.string().min(1).max(128) });
const codeSchema = z.object({ code: z.string().regex(/^\d{6}$/) });
const tokenSchema = z.object({ token: z.string().min(30).max(200) });
const passwordSchema = z.object({ token: z.string().min(30).max(200), password: z.string().min(10).max(128).regex(/[A-Za-z]/).regex(/[0-9]/) });

const cookieName = "finora_refresh";
const refreshCookieOptions = () => ({
  httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict" as const,
  path: "/api/auth", maxAge: 30 * 24 * 60 * 60 * 1000
});
function setRefreshCookie(res: Response, token: string) { res.cookie(cookieName, token, refreshCookieOptions()); }
function clearRefreshCookie(res: Response) { res.clearCookie(cookieName, { ...refreshCookieOptions(), maxAge: undefined }); }
function parse<T extends z.ZodTypeAny>(schema: T, body: unknown): z.infer<T> | null {
  const result = schema.safeParse(body);
  return result.success ? result.data : null;
}
function safeError(res: Response, status: number, message: string) { res.status(status).json({ error: message }); }

async function createSession(userId: string, res: Response) {
  const membership = await prisma.workspaceMember.findFirst({
    where: { userId }, orderBy: { joinedAt: "asc" }, include: { workspace: true }
  });
  if (!membership) throw new Error("User workspace is not configured");
  const refresh = createRefreshSecret();
  await prisma.refreshToken.create({ data: {
    userId, tokenHash: hashRefreshSecret(refresh),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  }});
  setRefreshCookie(res, refresh);
  return {
    accessToken: issueAccessToken(userId, membership.workspaceId, membership.role),
    user: { id: userId, workspaceId: membership.workspaceId, role: membership.role }
  };
}

export async function register(req: Request, res: Response): Promise<void> {
  const input = parse(registerSchema, req.body);
  if (!input) { safeError(res, 400, "Please provide a valid name, email and password (10+ characters, including letters and numbers)."); return; }
  try {
    const existing = await prisma.user.findUnique({ where: { email: input.email } });
    if (existing) { safeError(res, 409, "An account with this email already exists."); return; }
    const passwordHash = await bcrypt.hash(input.password, 12);
    const token = createOpaqueToken();
    const user = await prisma.$transaction(async tx => {
      const created = await tx.user.create({ data: { email: input.email, displayName: input.displayName, passwordHash } });
      const workspace = await tx.workspace.create({ data: { name: `${input.displayName}'s workspace` } });
      await tx.workspaceMember.create({ data: { userId: created.id, workspaceId: workspace.id, role: "ADMIN" } });
      await tx.emailVerificationToken.create({ data: {
        userId: created.id, tokenHash: hashRefreshSecret(token), expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
      }});
      return created;
    });
    const link = `${process.env.FRONTEND_ORIGIN}/verify-email?token=${encodeURIComponent(token)}`;
    await sendSecurityEmail(user.email, "Verify your FINORA email", `Welcome to FINORA. Verify your email using this link: ${link}\nThis link expires in 24 hours.`);
    res.status(201).json({ message: "Account created. Check your email to verify your address before signing in." });
  } catch (error) {
    console.error("Registration failed", error);
    safeError(res, 500, "Unable to create account right now.");
  }
}

export async function verifyEmail(req: Request, res: Response): Promise<void> {
  const input = parse(tokenSchema, req.body);
  if (!input) { safeError(res, 400, "Invalid verification request."); return; }
  const tokenHash = hashRefreshSecret(input.token);
  const record = await prisma.emailVerificationToken.findUnique({ where: { tokenHash } });
  if (!record || record.usedAt || record.expiresAt < new Date()) { safeError(res, 400, "Verification link is invalid or expired."); return; }
  await prisma.$transaction([
    prisma.user.update({ where: { id: record.userId }, data: { emailVerifiedAt: new Date() } }),
    prisma.emailVerificationToken.update({ where: { id: record.id }, data: { usedAt: new Date() } })
  ]);
  res.json({ message: "Email verified. You can now sign in." });
}

export async function login(req: Request, res: Response): Promise<void> {
  const input = parse(loginSchema, req.body);
  if (!input) { safeError(res, 400, "Invalid email or password."); return; }
  const user = await prisma.user.findUnique({ where: { email: input.email } });
  const valid = user ? await bcrypt.compare(input.password, user.passwordHash) : false;
  if (!user || !valid) { safeError(res, 401, "Invalid email or password."); return; }
  if (!user.emailVerifiedAt) { safeError(res, 403, "Please verify your email before signing in."); return; }
  if (user.mfaEnabled) {
    res.json({ mfaRequired: true, challengeToken: issueMfaChallenge(user.id) });
    return;
  }
  try { res.json({ mfaRequired: false, ...(await createSession(user.id, res)) }); }
  catch { safeError(res, 500, "Unable to create session."); }
}

export async function completeMfaLogin(req: Request, res: Response): Promise<void> {
  const challenge = typeof req.body?.challengeToken === "string" ? req.body.challengeToken : "";
  const input = parse(codeSchema, req.body);
  if (!challenge || !input) { safeError(res, 400, "A valid challenge and six-digit code are required."); return; }
  try {
    const { sub } = verifyMfaChallenge(challenge);
    const user = await prisma.user.findUnique({ where: { id: sub } });
    if (!user?.mfaEnabled || !user.mfaSecretEncrypted || !authenticator.verify({ token: input.code, secret: decryptField(user.mfaSecretEncrypted) })) {
      safeError(res, 401, "Invalid verification code."); return;
    }
    res.json(await createSession(user.id, res));
  } catch { safeError(res, 401, "MFA challenge expired or invalid."); }
}

export async function refreshSession(req: Request, res: Response): Promise<void> {
  const oldToken = req.cookies?.[cookieName];
  if (typeof oldToken !== "string") { safeError(res, 401, "Session expired."); return; }
  const oldHash = hashRefreshSecret(oldToken);
  try {
    const result = await prisma.$transaction(async tx => {
      const stored = await tx.refreshToken.findUnique({ where: { tokenHash: oldHash } });
      if (!stored) return { error: "invalid" as const };
      if (stored.revokedAt) {
        await tx.refreshToken.updateMany({ where: { userId: stored.userId, revokedAt: null }, data: { revokedAt: new Date() } });
        return { error: "reuse" as const };
      }
      if (stored.expiresAt < new Date()) {
        await tx.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });
        return { error: "expired" as const };
      }
      const membership = await tx.workspaceMember.findFirst({ where: { userId: stored.userId }, orderBy: { joinedAt: "asc" } });
      if (!membership) return { error: "invalid" as const };
      const next = createRefreshSecret();
      await tx.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } });
      await tx.refreshToken.create({ data: { userId: stored.userId, tokenHash: hashRefreshSecret(next), expiresAt: new Date(Date.now() + 30 * 86400000) } });
      return { next, userId: stored.userId, workspaceId: membership.workspaceId, role: membership.role };
    }, { isolationLevel: "Serializable" });
    if ("error" in result) { clearRefreshCookie(res); safeError(res, 401, "Session expired. Please sign in again."); return; }
    setRefreshCookie(res, result.next);
    res.json({ accessToken: issueAccessToken(result.userId, result.workspaceId, result.role) });
  } catch { clearRefreshCookie(res); safeError(res, 401, "Unable to refresh session."); }
}

export async function logout(req: Request, res: Response): Promise<void> {
  const token = req.cookies?.[cookieName];
  if (typeof token === "string") await prisma.refreshToken.updateMany({
    where: { tokenHash: hashRefreshSecret(token), revokedAt: null }, data: { revokedAt: new Date() }
  });
  clearRefreshCookie(res);
  res.status(204).send();
}

export async function forgotPassword(req: Request, res: Response): Promise<void> {
  const email = z.string().email().safeParse(req.body?.email);
  if (!email.success) { safeError(res, 400, "Enter a valid email address."); return; }
  const user = await prisma.user.findUnique({ where: { email: email.data.toLowerCase() } });
  if (user) {
    const token = createOpaqueToken();
    await prisma.passwordResetToken.create({ data: {
      userId: user.id, tokenHash: hashRefreshSecret(token), expiresAt: new Date(Date.now() + 30 * 60 * 1000)
    }});
    const link = `${process.env.FRONTEND_ORIGIN}/reset-password?token=${encodeURIComponent(token)}`;
    await sendSecurityEmail(user.email, "Reset your FINORA password", `Use this one-time link within 30 minutes: ${link}`);
  }
  res.json({ message: "If an account exists for that email, password reset instructions have been sent." });
}

export async function resetPassword(req: Request, res: Response): Promise<void> {
  const input = parse(passwordSchema, req.body);
  if (!input) { safeError(res, 400, "Invalid reset request or password."); return; }
  const tokenHash = hashRefreshSecret(input.token);
  const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash } });
  if (!record || record.usedAt || record.expiresAt < new Date()) { safeError(res, 400, "Reset link is invalid or expired."); return; }
  const passwordHash = await bcrypt.hash(input.password, 12);
  await prisma.$transaction([
    prisma.user.update({ where: { id: record.userId }, data: { passwordHash } }),
    prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    prisma.refreshToken.updateMany({ where: { userId: record.userId, revokedAt: null }, data: { revokedAt: new Date() } })
  ]);
  res.json({ message: "Password updated. Please sign in again." });
}

export async function beginMfaEnrollment(req: Request, res: Response): Promise<void> {
  const user = await prisma.user.findUnique({ where: { id: req.auth!.userId } });
  if (!user) { safeError(res, 404, "User not found."); return; }
  const secret = authenticator.generateSecret();
  await prisma.user.update({ where: { id: user.id }, data: { mfaSecretEncrypted: encryptField(secret) } });
  res.json({ otpauthUrl: authenticator.keyuri(user.email, "FINORA", secret), message: "Add this account to your authenticator app, then verify a code to enable MFA." });
}

export async function confirmMfaEnrollment(req: Request, res: Response): Promise<void> {
  const input = parse(codeSchema, req.body);
  if (!input) { safeError(res, 400, "Enter a six-digit code."); return; }
  const user = await prisma.user.findUnique({ where: { id: req.auth!.userId } });
  if (!user?.mfaSecretEncrypted || !authenticator.verify({ token: input.code, secret: decryptField(user.mfaSecretEncrypted) })) {
    safeError(res, 400, "Invalid authenticator code."); return;
  }
  await prisma.user.update({ where: { id: user.id }, data: { mfaEnabled: true } });
  res.json({ message: "Multi-factor authentication enabled." });
}

export async function disableMfa(req: Request, res: Response): Promise<void> {
  const input = parse(codeSchema, req.body);
  if (!input) { safeError(res, 400, "Enter a six-digit code."); return; }
  const user = await prisma.user.findUnique({ where: { id: req.auth!.userId } });
  if (!user?.mfaEnabled || !user.mfaSecretEncrypted || !authenticator.verify({ token: input.code, secret: decryptField(user.mfaSecretEncrypted) })) {
    safeError(res, 400, "Invalid authenticator code."); return;
  }
  await prisma.user.update({ where: { id: user.id }, data: { mfaEnabled: false, mfaSecretEncrypted: null } });
  res.json({ message: "Multi-factor authentication disabled." });
}

export function trustedOrigin(req: Request, res: Response, next: NextFunction): void {
  const allowed = (process.env.FRONTEND_ORIGIN ?? "").split(",").map(v => v.trim()).filter(Boolean);
  const origin = req.get("origin");
  if (origin && allowed.includes(origin)) { next(); return; }
  safeError(res, 403, "Untrusted request origin.");
}
