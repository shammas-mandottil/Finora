import type { Request, Response } from "express";
import { getDashboard } from "../services/dashboard.js";
export async function dashboard(req: Request, res: Response): Promise<void> {
  try { res.json(await getDashboard(req.auth!.workspaceId)); }
  catch { res.status(500).json({ error: "Unable to load dashboard" }); }
}
