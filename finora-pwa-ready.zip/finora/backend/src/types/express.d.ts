declare global {
  namespace Express {
    interface Request { auth?: { userId: string; workspaceId: string; role: "ADMIN" | "EDITOR" | "VIEWER" } }
  }
}
export {};
