import "dotenv/config";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import authRouter from "./routes.auth.js";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import cron from "node-cron";
import router from "./routes.js";
import { prisma } from "./lib/prisma.js";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN?.split(",") ?? [], credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use("/api/auth", authRouter);
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }));
app.use("/api", router);

cron.schedule("0 8 * * *", async () => {
  const due = await prisma.bill.findMany({ where: { isActive: true, dueAt: { gte: new Date(), lte: new Date(Date.now() + 3 * 86400000) } } });
  for (const bill of due) {
    const members = await prisma.workspaceMember.findMany({ where: { workspaceId: bill.workspaceId }, select: { userId: true } });
    await prisma.notification.createMany({ data: members.map(m => ({ userId: m.userId, type: "BILL_REMINDER" as const, title: "Upcoming bill", body: `${bill.name} is due soon.` })) });
  }
});

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => console.log(`FINORA API listening on ${port}`));
process.on("SIGTERM", async () => { await prisma.$disconnect(); process.exit(0); });
