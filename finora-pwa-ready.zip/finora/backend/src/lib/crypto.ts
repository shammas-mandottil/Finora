import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";

const key = (): Buffer => {
  const raw = process.env.FIELD_ENCRYPTION_KEY;
  if (!raw) throw new Error("FIELD_ENCRYPTION_KEY is required");
  const decoded = Buffer.from(raw, "base64");
  if (decoded.length !== 32) throw new Error("FIELD_ENCRYPTION_KEY must decode to 32 bytes");
  return decoded;
};

export function encryptField(plainText: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key(), iv);
  const encrypted = Buffer.concat([cipher.update(plainText, "utf8"), cipher.final()]);
  return [iv, cipher.getAuthTag(), encrypted].map(v => v.toString("base64")).join(".");
}
export function decryptField(payload: string): string {
  const [iv, tag, encrypted] = payload.split(".").map(v => Buffer.from(v, "base64"));
  if (!iv || !tag || !encrypted) throw new Error("Invalid encrypted field");
  const decipher = createDecipheriv("aes-256-gcm", key(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString("utf8");
}
