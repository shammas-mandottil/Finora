import { Prisma } from "@prisma/client";
export const decimal = (value: string | number | Prisma.Decimal) => new Prisma.Decimal(value);
export const moneyString = (value: Prisma.Decimal) => value.toFixed(2);
