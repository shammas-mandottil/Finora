import type { Request, Response, NextFunction } from "express";
import type { ZodSchema } from "zod";
export const validateBody = (schema: ZodSchema) => (req: Request, res: Response, next: NextFunction): void => {
  const result = schema.safeParse(req.body);
  if (!result.success) { res.status(400).json({ error: "Invalid request", details: result.error.flatten() }); return; }
  req.body = result.data;
  next();
};
