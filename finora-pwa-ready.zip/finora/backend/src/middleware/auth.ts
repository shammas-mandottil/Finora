import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

type Claims = { sub: string; workspaceId: string; role: "ADMIN" | "EDITOR" | "VIEWER" };
export function authenticate(req: Request, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) { res.status(401).json({ error: "Authentication required" }); return; }
  try {
    const claims = jwt.verify(header.slice(7), process.env.JWT_ACCESS_SECRET!, {
      issuer: "finora-api", audience: "finora-web"
    }) as Claims;
    if (!claims.sub || !claims.workspaceId || !claims.role) throw new Error("Invalid claims");
    req.auth = { userId: claims.sub, workspaceId: claims.workspaceId, role: claims.role };
    next();
  } catch { res.status(401).json({ error: "Invalid or expired access token" }); }
}
export const requireRole = (...roles: Claims["role"][]) => (req: Request, res: Response, next: NextFunction): void => {
  if (!req.auth || !roles.includes(req.auth.role)) { res.status(403).json({ error: "Insufficient workspace permissions" }); return; }
  next();
};
