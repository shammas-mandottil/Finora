import { Prisma } from "@prisma/client";
import { prisma } from "../lib/prisma.js";

const zero = new Prisma.Decimal(0);
export async function getDashboard(workspaceId: string, months = 6) {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - months + 1, 1);
  const [accounts, transactions, goals, debts, investments] = await Promise.all([
    prisma.account.findMany({ where: { workspaceId, isArchived: false } }),
    prisma.transaction.findMany({ where: { workspaceId, transactionDate: { gte: start }, isInternal: false, status: "CLEARED" }, include: { category: true }, orderBy: { transactionDate: "asc" } }),
    prisma.goal.findMany({ where: { workspaceId, status: "ACTIVE" } }),
    prisma.debt.findMany({ where: { workspaceId } }),
    prisma.investment.findMany({ where: { workspaceId } })
  ]);
  const assets = accounts.filter(a => a.type !== "CREDIT_CARD" && a.type !== "LOAN").reduce((s,a) => s.add(a.currentBalance), zero)
    .add(investments.reduce((s,i) => s.add(i.quantity.mul(i.currentPrice)), zero));
  const liabilities = accounts.filter(a => a.type === "CREDIT_CARD" || a.type === "LOAN").reduce((s,a) => s.add(a.currentBalance.abs()), zero)
    .add(debts.reduce((s,d) => s.add(d.balance), zero));
  const monthly = new Map<string, { income: Prisma.Decimal; expense: Prisma.Decimal }>();
  for (let i = 0; i < months; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - months + 1 + i, 1);
    monthly.set(d.toISOString().slice(0,7), { income: zero, expense: zero });
  }
  const categories = new Map<string, Prisma.Decimal>();
  for (const t of transactions) {
    const key = t.transactionDate.toISOString().slice(0,7);
    const row = monthly.get(key);
    if (row && t.type === "INCOME") row.income = row.income.add(t.baseAmount);
    if (row && t.type === "EXPENSE") {
      row.expense = row.expense.add(t.baseAmount);
      const name = t.category?.name ?? "Uncategorized";
      categories.set(name, (categories.get(name) ?? zero).add(t.baseAmount));
    }
  }
  const history = [...monthly.entries()].map(([month,v]) => ({ month, income: v.income.toNumber(), expense: v.expense.toNumber(), net: v.income.sub(v.expense).toNumber() }));
  const avgNet = history.length ? history.reduce((s,v) => s + v.net, 0) / history.length : 0;
  const forecast = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() + i + 1, 1);
    return { month: d.toLocaleString("en-IN", { month: "short", year: "2-digit" }), projectedNet: Number((avgNet * (i + 1)).toFixed(2)) };
  });
  return {
    currency: "INR",
    netWorth: assets.sub(liabilities).toFixed(2),
    totalAssets: assets.toFixed(2), totalLiabilities: liabilities.toFixed(2),
    accountCount: accounts.length,
    cashFlow: history,
    categories: [...categories.entries()].map(([name,value]) => ({ name, value: value.toNumber() })).sort((a,b) => b.value-a.value),
    goals: goals.map(g => ({ id: g.id, name: g.name, target: g.targetAmount.toString(), current: g.currentAmount.toString(),
      progress: g.targetAmount.gt(0) ? Math.min(100, g.currentAmount.div(g.targetAmount).mul(100).toNumber()) : 0 })),
    creditUtilization: accounts.filter(a => a.type === "CREDIT_CARD").map(a => ({ name: a.name, balance: a.currentBalance.toString() })),
    forecast
  };
}
