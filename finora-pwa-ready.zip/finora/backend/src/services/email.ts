import nodemailer from "nodemailer";

const from = process.env.MAIL_FROM ?? "FINORA <no-reply@example.test>";
const transport = process.env.SMTP_HOST
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT ?? 587),
      secure: process.env.SMTP_SECURE === "true",
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS ?? "" } : undefined
    })
  : null;

export async function sendSecurityEmail(to: string, subject: string, text: string): Promise<void> {
  if (!transport) {
    if (process.env.NODE_ENV === "production") throw new Error("SMTP must be configured in production");
    console.info(`[development mail] To: ${to}\nSubject: ${subject}\n${text}`);
    return;
  }
  await transport.sendMail({ from, to, subject, text });
}
