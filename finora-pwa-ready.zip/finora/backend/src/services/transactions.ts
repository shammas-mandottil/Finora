import { Prisma, TransactionType } from "@prisma/client";
import { prisma } from "../lib/prisma.js";
import { decimal } from "../lib/money.js";

type CreateInput = {
  accountId: string; type: "INCOME" | "EXPENSE"; amount: string; currency: string;
  baseAmount: string; description: string; merchant?: string; categoryId?: string;
  transactionDate: string; createdById: string; workspaceId: string;
};

const fingerprint = (x: CreateInput): string =>
  [x.accountId, x.type, decimal(x.amount).toFixed(2), x.currency.toUpperCase(),
   new Date(x.transactionDate).toISOString().slice(0, 10), x.description.trim().toLowerCase()].join("|");

export async function createTransaction(input: CreateInput) {
  const amount = decimal(input.amount);
  const baseAmount = decimal(input.baseAmount);
  if (!amount.isFinite() || amount.lte(0) || !baseAmount.isFinite() || baseAmount.lte(0)) throw new Error("Amount must be positive");
  return prisma.$transaction(async tx => {
    const account = await tx.account.findFirst({ where: { id: input.accountId, workspaceId: input.workspaceId, isArchived: false } });
    if (!account) throw new Error("Account not found in this workspace");
    const fp = fingerprint(input);
    const duplicate = await tx.transaction.findFirst({ where: { workspaceId: input.workspaceId, fingerprint: fp } });
    if (duplicate) return { transaction: duplicate, duplicate: true };
    const signed = input.type === "INCOME" ? amount : amount.negated();
    const created = await tx.transaction.create({ data: {
      workspaceId: input.workspaceId, accountId: input.accountId, createdById: input.createdById,
      type: input.type as TransactionType, amount, baseAmount, currency: input.currency.toUpperCase(),
      description: input.description, merchant: input.merchant, categoryId: input.categoryId,
      transactionDate: new Date(input.transactionDate), fingerprint: fp
    }});
    await tx.account.update({ where: { id: account.id }, data: { currentBalance: { increment: signed } } });
    const counterpart = await tx.transaction.findFirst({
      where: { workspaceId: input.workspaceId, id: { not: created.id }, isInternal: false,
        type: input.type === "EXPENSE" ? "INCOME" : "EXPENSE",
        amount, transactionDate: { gte: new Date(new Date(input.transactionDate).getTime() - 2 * 86400000),
          lte: new Date(new Date(input.transactionDate).getTime() + 2 * 86400000) },
        description: { contains: "transfer", mode: "insensitive" } }
    });
    if (counterpart && counterpart.accountId !== input.accountId) {
      // Keep both balance movements: transfers change each account balance.
      // Marking them internal only excludes them from income/expense analytics.
      const pairId = `transfer_${[created.id, counterpart.id].sort().join("_")}`;
      await tx.transaction.updateMany({ where: { id: { in: [created.id, counterpart.id] } }, data: { isInternal: true, transferPairId: pairId } });
    }
    return { transaction: created, duplicate: false };
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}
