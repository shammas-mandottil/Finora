import jwt from "jsonwebtoken";
import { createHash, randomBytes } from "node:crypto";

function secret(name: "JWT_ACCESS_SECRET" | "JWT_REFRESH_SECRET"): string {
  const value = process.env[name];
  if (!value || value.length < 32) throw new Error(`${name} must be configured with at least 32 characters`);
  return value;
}
export function issueAccessToken(userId: string, workspaceId: string, role: "ADMIN"|"EDITOR"|"VIEWER"): string {
  return jwt.sign({ workspaceId, role }, secret("JWT_ACCESS_SECRET"), {
    subject: userId, expiresIn: "15m", issuer: "finora-api", audience: "finora-web"
  });
}
export function issueMfaChallenge(userId: string): string {
  return jwt.sign({ purpose: "mfa" }, secret("JWT_ACCESS_SECRET"), {
    subject: userId, expiresIn: "5m", issuer: "finora-api", audience: "finora-mfa"
  });
}
export function verifyMfaChallenge(token: string): { sub: string } {
  const value = jwt.verify(token, secret("JWT_ACCESS_SECRET"), { issuer: "finora-api", audience: "finora-mfa" }) as jwt.JwtPayload;
  if (!value.sub || value.purpose !== "mfa") throw new Error("Invalid MFA challenge");
  return { sub: value.sub };
}
export function createRefreshSecret(): string { return randomBytes(48).toString("base64url"); }
export function createOpaqueToken(): string { return randomBytes(32).toString("base64url"); }
export function hashRefreshSecret(token: string): string { return createHash("sha256").update(token).digest("hex"); }
