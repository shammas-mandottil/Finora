import { authenticator } from "otplib";
import { encryptField, decryptField } from "../lib/crypto.js";
export function createMfaSecret(email: string) {
  const secret = authenticator.generateSecret();
  return { encryptedSecret: encryptField(secret), otpauthUrl: authenticator.keyuri(email, "FINORA", secret) };
}
export function verifyMfaCode(encryptedSecret: string, token: string): boolean {
  return authenticator.verify({ token, secret: decryptField(encryptedSecret) });
}
