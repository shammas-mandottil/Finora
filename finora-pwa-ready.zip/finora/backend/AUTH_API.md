# FINORA Authentication API

All routes are mounted under `/api/auth`.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/register` | Create user, personal workspace, Admin membership and verification email |
| POST | `/verify-email` | Consume single-use email verification token |
| POST | `/login` | Verify password; return access token or MFA challenge |
| POST | `/mfa/challenge` | Complete six-digit MFA challenge and establish session |
| POST | `/refresh` | Rotate refresh token stored in HTTP-only cookie |
| POST | `/logout` | Revoke current refresh session and clear cookie |
| POST | `/forgot-password` | Send single-use password reset link |
| POST | `/reset-password` | Change password and revoke existing refresh sessions |
| POST | `/mfa/enroll` | Authenticated: create encrypted pending MFA seed and return otpauth URL |
| POST | `/mfa/confirm` | Authenticated: verify code and enable MFA |
| POST | `/mfa/disable` | Authenticated: verify code and disable MFA |

## Request examples

Register:
```json
{ "displayName": "A User", "email": "user@example.com", "password": "LongPassword123" }
```

Login:
```json
{ "email": "user@example.com", "password": "LongPassword123" }
```

MFA challenge:
```json
{ "challengeToken": "short-lived-challenge-jwt", "code": "123456" }
```

Refresh and logout require browser credentials (`credentials: "include"`) and a trusted `Origin`. Access tokens should be held in memory by the SPA and sent as Bearer tokens. Never store refresh tokens in localStorage or expose them to JavaScript.

## Required migration
After changing `schema.prisma`:
```bash
npx prisma generate
npx prisma migrate dev --name auth_tokens
```

## Important hardening before public launch
- Add CSRF protection / strict Origin validation at the reverse proxy and application layer for all cookie-authenticated routes.
- Add password breach checks, login lockout / progressive throttling, MFA recovery codes and a support recovery process.
- Ensure email verification and reset links use a configured HTTPS frontend origin.
- Add transactional outbox delivery so email failures do not leave orphaned account state.
- Add concurrency tests for refresh-token reuse and token rotation.
- Use a secrets manager and TLS-only deployment; configure cookie domain and proxy trust explicitly.
- The MFA enrollment response includes an otpauth URL. Display it only to the authenticated user and do not log it.
- A production email provider and delivery monitoring are required. Development mail is logged to the server console only.
